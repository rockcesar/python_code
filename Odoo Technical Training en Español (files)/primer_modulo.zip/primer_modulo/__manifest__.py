# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Primer módulo',
    'depends': ['base','crm'],
    'description': """
        
        Primer módulo.
        
    """,
    'website': 'Primer módulo',
    'category': 'Sales',
    'sequence': 32,
    'demo': [
    ],
    'data': [
        'reports/template_report.xml',
        'views/carro_v.xml',
        'views/casa_v.xml',
        'views/persona_v.xml',
        'views/res_partner_h.xml',
        'security/groups_security.xml',
        'views/menus_v.xml',
        'security/ir.model.access.csv',
    ],
    'qweb': [
    ],
}
