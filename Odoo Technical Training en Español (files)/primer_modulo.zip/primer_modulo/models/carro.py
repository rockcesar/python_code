# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError

class carro(models.Model):
    _name = "carro"
    _description = "Carro"

    name = fields.Char('Nombre')
    description = fields.Char('Descripción')
    persona_id = fields.Many2one(
        'persona',
        ondelete='restrict',
        string=u'Persona',
        required=False,
    )
    photo_persona = fields.Binary(related="persona_id.photo")
