# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError

class casa(models.Model):
    _name = "casa"
    _description = "Casa"
    _inherit = ['casa']

    house_number = fields.Char('Número de casa')
