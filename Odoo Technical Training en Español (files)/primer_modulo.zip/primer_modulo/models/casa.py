# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError

class casa(models.Model):
    _name = "casa"
    _description = "Casa"

    name = fields.Char('Nombre')
    description = fields.Char('Descripción')
    personas_ids = fields.Many2many(
        comodel_name='persona',
        relation='persona_casa_rel',
        column1='casa_id',
        column2='persona_id',
        string=u'Personas que habitan',
        help=u'Personas que habitan'
    )
