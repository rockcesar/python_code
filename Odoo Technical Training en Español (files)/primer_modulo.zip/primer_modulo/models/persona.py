# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError

import logging

_logger = logging.getLogger(__name__)

class persona(models.Model):
    _name = "persona"
    _description = "Persona"

    name = fields.Char('Nombre')
    last_name = fields.Char('Apellido')
    age = fields.Integer('Edad')
    wallet = fields.Float('Monedero')
    sex = fields.Selection([
                            ('masculino', 'Masculino'),
                            ('femenino', 'Femenino'),],
                            string='Sexo', default='masculino')
    casas_ids = fields.Many2many(
        comodel_name='casa',
        relation='persona_casa_rel',
        column1='persona_id',
        column2='casa_id',
        string=u'Casas de la persona',
        help=u'Casas de la persona'
    )
    carro_ids = fields.One2many(
        comodel_name='carro',
        inverse_name='persona_id',
        string=u'Carros',
        help=u'Carros de la persona'
    )
    photo = fields.Binary(
                string=u'Foto de la persona',
                required=False
    )
    photo_litle = fields.Binary(string='Foto de la persona',
                                compute="_compute_photo_depends",
                                store=False)
    
    @api.depends('photo')
    def _compute_photo_depends(self):
        for person in self:
            if person.photo:
                person.photo_litle = person.photo
            else:
                person.photo_litle = False

    @api.model
    def create(self, vals):
        persona_id = super(persona, self).create(vals)

        return persona_id
    
    def write(self, vals):
        if 'casas_ids' in vals:
            casa_obj = self.env['casa']
            _logger.info("Self " + str(vals['casas_ids']))
            casa_ids = casa_obj.search([('id', 'in', vals['casas_ids'][0][2])])
            _logger.info("Casas " + str(casa_ids))
            casa_result = casa_obj.browse(vals['casas_ids'][0][2])
            _logger.info("Casa result " + str(casa_result))
            casa_read = casa_obj.search_read([('id', 'in', vals['casas_ids'][0][2])], ['id','description'])
            _logger.info("Casa read " + str(casa_read))

        result = super(persona, self).write(vals)

        return result
    
    def unlink(self):
        unlink_result = super(persona, self).unlink()
        
        return unlink_result
