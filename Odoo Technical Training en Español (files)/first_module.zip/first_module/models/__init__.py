# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import car
from . import house
from . import res_partner_h
from . import person
from . import house_h
