First Module (for learning Odoo)
=====================================



Credits
=======

Contributors
------------

* César Cordero Rodríguez <cesar.cordero.r@gmail.com>
